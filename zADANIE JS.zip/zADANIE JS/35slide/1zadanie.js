let str = 'abcde';

console.log(str[0]);
console.log(str[2]);
console.log(str[4]);