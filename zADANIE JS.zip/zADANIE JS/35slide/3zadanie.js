let secondsInHour = 60 * 60;
console.log("Количество секунд в часе: " + secondsInHour);

let secondsInDay = 24 * secondsInHour;
console.log("Количество секунд в сутках: " + secondsInDay);

let secondsInMonth = 30 * secondsInDay;
console.log("Количество секунд в месяце : " + secondsInMonth);