let number = 6;
let square = number * number;
console.log(square);