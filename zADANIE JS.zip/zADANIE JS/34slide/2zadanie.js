let str1 = 'Привет, ';
let str2 = 'Мир!';

let greeting = str1 + str2;

console.log(greeting);