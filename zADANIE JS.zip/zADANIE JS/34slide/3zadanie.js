let name = 'Радмир';
let greeting = 'Привет, ' + name + '!';

console.log(greeting);