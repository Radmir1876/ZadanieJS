let number = prompt("Введите число:");
let square = number * number;
alert('Квадрат числа ' + number + ' равен ' + square);