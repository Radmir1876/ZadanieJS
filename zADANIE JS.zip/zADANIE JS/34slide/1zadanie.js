let str = 'Привет, Мир!';
console.log(str);