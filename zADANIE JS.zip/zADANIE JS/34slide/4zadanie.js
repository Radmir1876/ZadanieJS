let age = 16;
let ageStatement = 'Мне ' + age + ' лет!';

console.log(ageStatement);