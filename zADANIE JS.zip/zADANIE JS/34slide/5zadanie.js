let userName = prompt("Введите ваше имя:");
alert('Ваше имя ' + userName);