let a = 10;
let b = 2;

let sum = a + b;
let difference = a - b;
let product = a * b;
let quotient = a / b;

console.log("Сумма: " + sum);
console.log("Разность: " + difference);
console.log("Произведение: " + product);
console.log("Частное: " + quotient);