let a = 10;
let b = 2;
let c = 5;

let sum = a + b + c;

console.log("Сумма: " + sum);