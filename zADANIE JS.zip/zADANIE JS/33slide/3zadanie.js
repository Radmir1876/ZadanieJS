let c = 15;
let d = 2;

let result = c + d;

console.log("Результат: " + result);