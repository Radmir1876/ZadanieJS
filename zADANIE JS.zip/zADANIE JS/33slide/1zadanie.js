let num = 3;
alert(num);
