let a = 17;
let b = 10;
let c = a - b;

let d = 7;
let result = c + d;

console.log("Результат: " + result);