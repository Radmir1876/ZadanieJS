let a = 2; 
let x = 1+(a *=2);

a = 4
x = 5